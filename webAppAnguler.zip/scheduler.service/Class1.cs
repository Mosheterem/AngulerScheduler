﻿using System;

namespace scheduler.service
{
    public class Class1
    {
    }
}
