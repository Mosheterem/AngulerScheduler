﻿using System;
using System.Collections.Generic;
using System.Text;

namespace scheduler.EF.ComplexTypes
{
    public class TempData
    {
        public int id { get; set; }
        public string text { get; set; }
        public string color { get; set; }
        public bool IsCheked { get; set; }
    }

}
