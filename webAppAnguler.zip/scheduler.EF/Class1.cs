﻿using System;

namespace scheduler.EF
{
    public class Class1
    {
    }
}
