﻿using System;
using System.Collections.Generic;
using System.Text;

namespace scheduler.Model
{
  public class GetreportData
    {
        public DateTime maxDate { get; set; }
        public DateTime minDate { get; set; }
    }
}
