﻿using System;

namespace scheduler.Model
{
    public class Class1
    {
    }
}
