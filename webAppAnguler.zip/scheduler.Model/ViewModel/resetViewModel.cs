﻿using System;
using System.Collections.Generic;
using System.Text;

namespace scheduler.Model.ViewModel
{
    public class resetViewModel
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public string NewPassword { get; set; }
    }
}
