﻿using AutoMapper;

namespace webAppAnguler
{
    public class Automapper : Profile
    {
        //public Automapper()
        //{
        //    //Mapping b/w TodoViewModel & TodoInfo
        //    CreateMap< List<Product>, List<ProductViewModel>>();

        //}
    }
}