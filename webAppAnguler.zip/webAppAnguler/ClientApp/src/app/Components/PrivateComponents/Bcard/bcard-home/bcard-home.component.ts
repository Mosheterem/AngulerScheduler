import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bcard-home',
  templateUrl: './bcard-home.component.html',
  styleUrls: ['./bcard-home.component.css']
})
export class BcardHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
