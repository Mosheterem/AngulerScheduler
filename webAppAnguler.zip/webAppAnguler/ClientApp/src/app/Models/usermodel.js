"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserModal = /** @class */ (function () {
    function UserModal() {
    }
    ;
    return UserModal;
}());
exports.UserModal = UserModal;
//# sourceMappingURL=usermodel.js.map