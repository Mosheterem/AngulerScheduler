﻿using System;

namespace scheduler.Repository
{
    public class Class1
    {
    }
}
